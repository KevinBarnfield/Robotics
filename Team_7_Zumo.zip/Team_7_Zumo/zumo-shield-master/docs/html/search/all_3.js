var searchData=
[
  ['init',['init',['../class_zumo_reflectance_sensor_array.html#a73e1db81cdea8116f86524eee10763c8',1,'ZumoReflectanceSensorArray::init(unsigned char emitterPin=ZUMO_SENSOR_ARRAY_DEFAULT_EMITTER_PIN)'],['../class_zumo_reflectance_sensor_array.html#aa6428ee034b6066dd8a6b9da85609eea',1,'ZumoReflectanceSensorArray::init(unsigned char *pins, unsigned char numSensors, unsigned int timeout=2000, unsigned char emitterPin=ZUMO_SENSOR_ARRAY_DEFAULT_EMITTER_PIN)']]],
  ['isplaying',['isPlaying',['../class_zumo_buzzer.html#af2d706d8312f12780b9a9ee5e80247de',1,'ZumoBuzzer']]]
];
