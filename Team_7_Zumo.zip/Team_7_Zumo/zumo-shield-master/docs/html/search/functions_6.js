var searchData=
[
  ['zumoreflectancesensorarray',['ZumoReflectanceSensorArray',['../class_zumo_reflectance_sensor_array.html#a19f33305b41d2dcb6d637474571a9e3f',1,'ZumoReflectanceSensorArray::ZumoReflectanceSensorArray()'],['../class_zumo_reflectance_sensor_array.html#a0622d191a377bc6d379693f60e55c681',1,'ZumoReflectanceSensorArray::ZumoReflectanceSensorArray(unsigned char emitterPin)'],['../class_zumo_reflectance_sensor_array.html#abc268241282ff838faefd2cc0e66c1e8',1,'ZumoReflectanceSensorArray::ZumoReflectanceSensorArray(unsigned char *pins, unsigned char numSensors, unsigned int timeout=2000, unsigned char emitterPin=ZUMO_SENSOR_ARRAY_DEFAULT_EMITTER_PIN)']]]
];
