var searchData=
[
  ['calibrate',['calibrate',['../class_q_t_r_sensors.html#ac9840e2429c7a962977057ba154c77da',1,'QTRSensors']]]
];
