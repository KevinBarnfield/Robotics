var searchData=
[
  ['read',['read',['../class_zumo_reflectance_sensor_array.html#a65339c9daf90ba1294b04aca43a58b99',1,'ZumoReflectanceSensorArray']]],
  ['readcalibrated',['readCalibrated',['../class_q_t_r_sensors.html#aa32a448ac03cd2a45d1f14f96ac4b739',1,'QTRSensors']]],
  ['readline',['readLine',['../class_q_t_r_sensors.html#ac84f0b98bceae0b59d687ae82eb92718',1,'QTRSensors']]],
  ['resetcalibration',['resetCalibration',['../class_q_t_r_sensors.html#aa840b6ef17562d41edf21ddd08e0672e',1,'QTRSensors']]]
];
